CREATE DATABASE employee_management_system;

USE employee_management_system;



-- Table 1: Job Department
CREATE TABLE JobDepartment (
Job_ID INT PRIMARY KEY,
jobdept VARCHAR(50),
name VARCHAR(100),
description TEXT,
salaryrange VARCHAR(50)
);

-- Table 2: Salary/Bonus
CREATE TABLE SalaryBonus (
salary_ID INT PRIMARY KEY,
Job_ID INT,
amount DECIMAL(10,2),
annual DECIMAL(10,2),
bonus DECIMAL(10,2),
CONSTRAINT fk_salary_job FOREIGN KEY (job_ID) REFERENCES JobDepartment(Job_ID)
ON DELETE CASCADE ON UPDATE CASCADE
);

-- Table 3: Employee
CREATE TABLE Employee (
emp_ID INT PRIMARY KEY,
firstname VARCHAR(50),
lastname VARCHAR(50),
gender VARCHAR(10),
age INT,
contact_add VARCHAR(100),
emp_email VARCHAR(100) UNIQUE,
emp_pass VARCHAR(50),
Job_ID INT,
CONSTRAINT fk_employee_job FOREIGN KEY (Job_ID)
REFERENCES JobDepartment(Job_ID)
ON DELETE SET NULL
ON UPDATE CASCADE
);

-- Table 4: Qualification
CREATE TABLE Qualification (
QualID INT PRIMARY KEY,
Emp_ID INT,
Position VARCHAR(50),
Requirements VARCHAR(255),
Date_In DATE,
CONSTRAINT fk_qualification_emp FOREIGN KEY (Emp_ID)
REFERENCES Employee(emp_ID)
ON DELETE CASCADE
ON UPDATE CASCADE
);

-- Table 5: Leaves
CREATE TABLE Leaves (
leave_ID INT PRIMARY KEY,
emp_ID INT,
date DATE,
reason TEXT,
CONSTRAINT fk_leave_emp FOREIGN KEY (emp_ID) REFERENCES Employee(emp_ID)
ON DELETE CASCADE ON UPDATE CASCADE
);

-- Table 6: Payroll
CREATE TABLE Payroll (
payroll_ID INT PRIMARY KEY,
emp_ID INT,
job_ID INT,
salary_ID INT,
leave_ID INT,
date DATE,
report TEXT,
total_amount DECIMAL(10,2),
CONSTRAINT fk_payroll_emp FOREIGN KEY (emp_ID) REFERENCES Employee(emp_ID)
ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT fk_payroll_job FOREIGN KEY (job_ID) REFERENCES JobDepartment(job_ID)
ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT fk_payroll_salary FOREIGN KEY (salary_ID) REFERENCES
SalaryBonus(salary_ID)
ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT fk_payroll_leave FOREIGN KEY (leave_ID) REFERENCES Leaves(leave_ID)
ON DELETE SET NULL ON UPDATE CASCADE
);



-- 1. EMPLOYEE INSIGHTS
# How many unique employees are currently in the system?
SELECT COUNT(DISTINCT emp_ID) AS "Total Employees"
FROM employee;

# Which departments have the highest number of employees?
SELECT j.jobdept AS "Department", COUNT(e.emp_ID) AS "Total Employees"
FROM employee AS e
INNER JOIN jobdepartment AS j
ON e.Job_ID = j.Job_ID 
GROUP BY j.jobdept
ORDER BY COUNT(e.emp_ID) DESC
LIMIT 2;

# What is the average salary per department?
SELECT j.jobdept AS "Department", ROUND(AVG(s.amount), 2) AS "Average Salary"
FROM jobdepartment AS j
INNER JOIN salarybonus AS s
ON j.Job_ID=s.Job_ID
GROUP BY j.jobdept;

# Who are the top 5 highest-paid employees?
SELECT e.emp_ID, CONCAT_WS(" ", e.firstname, e.lastname) AS "Full Name", s.amount
FROM employee AS e
INNER JOIN salarybonus AS s
ON e.Job_ID=s.Job_ID
ORDER BY s.amount DESC
LIMIT 5;

# What is the total salary expenditure across the company?
-- review
SELECT SUM(annual+bonus) AS "Total Expenditure" 
FROM salarybonus;  


-- 2. JOB ROLE AND DEPARTMENT ANALYSIS
# How many different job roles exist in each department?
SELECT jobdept AS "Department", COUNT(DISTINCT name) AS "Total Roles"
FROM jobdepartment
GROUP BY jobdept;

# What is the average salary range per department?
SELECT jobdept AS "Department", CONCAT_WS('-', MIN(s.amount), MAX(s.amount)) AS "Salary Range", ROUND(AVG(s.amount), 2) AS "Average Salary"
FROM jobdepartment AS j
INNER JOIN salarybonus AS s
ON j.Job_ID = s.Job_ID
GROUP BY j.jobdept;

# Which job roles offer the highest salary?
SELECT j.Job_ID AS "Job_ID", j.jobdept AS "Department", j.name AS "Role", s.amount AS "Salary"
FROM jobdepartment AS j
INNER JOIN salarybonus AS s
ON j.Job_ID = s.Job_ID
ORDER BY Salary DESC
LIMIT 2;

# Which departments have the highest total salary allocation?
SELECT j.jobdept AS "Department", SUM(s.amount) AS "Total Allocated Salary"
FROM jobdepartment AS j
INNER JOIN salarybonus AS s
ON j.Job_ID = s.Job_ID
GROUP BY j.jobdept
ORDER BY SUM(s.amount) DESC
LIMIT 3;



-- 3. QUALIFICATION AND SKILLS ANALYSIS
# How many employees have at least one qualification listed?
SELECT COUNT(DISTINCT emp_ID) AS "Total Employees with Atleast One Qualification"
FROM qualification;

# Which positions require the most qualifications?
SELECT Position, COUNT(Requirements) AS Total_Qualifications
FROM qualification 
GROUP BY Position
ORDER BY Total_Qualifications DESC;

# Which employees have the highest number of qualifications?
SELECT q.emp_ID, CONCAT_WS(" ", e.firstname, e.lastname) AS "Name", COUNT(q.QualID) AS "Total Qualifications"
FROM qualification AS q
INNER JOIN employee AS e
ON q.emp_ID = e.emp_ID
GROUP BY q.emp_ID
ORDER BY "Total Qualifications" DESC;



-- 4. LEAVE AND ABSENCE PATTERNS
# Which year had the most employees taking leaves?
SELECT YEAR(date) AS "Most Leaves In", COUNT(DISTINCT emp_ID) AS "Total Employees"
FROM leaves
GROUP BY YEAR(date)
ORDER BY "Total Employees" DESC
LIMIT 1;

# What is the average number of leave days taken by its employees per department?
SELECT j.jobdept, ROUND(COUNT(l.leave_ID)/COUNT(e.emp_ID), 2) AS "Average Leaves"
FROM employee AS e
INNER JOIN leaves AS l
ON e.emp_ID = l.emp_ID
LEFT JOIN jobdepartment AS j
ON e.Job_ID = j.Job_ID
GROUP BY j.jobdept;

# Which employees have taken the most leaves?
SELECT l.emp_ID, CONCAT_WS(" ", e.firstname, e.lastname) AS "Name", COUNT(l.leave_ID) AS "Total Leaves"
FROM leaves AS l
INNER JOIN employee AS e
ON e.emp_ID = l.emp_ID
GROUP BY l.emp_ID
ORDER BY "Total leaves" DESC;

# What is the total number of leave days taken company-wide?
SELECT COUNT(DISTINCT date) AS "Total Leaves Days"
FROM leaves;

# How do leave days correlate with payroll amounts?
SELECT p.emp_ID, COUNT(l.leave_ID) AS "Leave Days", ROUND(AVG(p.total_amount), 2) AS "Average Payroll"
FROM Payroll AS p
INNER JOIN leaves AS l ON p.leave_ID = l.leave_ID
GROUP BY p.emp_ID;


-- 5. PAYROLL AND COMPENSATION ANALYSIS
# What is the total monthly payroll processed?
SELECT DATE_FORMAT(date, "%Y-%M") AS Month, SUM(total_amount) AS "Total Monthly Payroll" 
FROM payroll
GROUP BY Month;

# What is the average bonus given per department?
SELECT j.jobdept AS "Department", ROUND(AVG(s.bonus), 2) AS "Average Bonus"
FROM jobdepartment AS j
INNER JOIN salarybonus AS s
ON s.Job_ID = j.Job_ID
GROUP BY j.jobdept;

# Which department receives the highest total bonuses?
SELECT j.jobdept AS "Department", SUM(s.bonus) AS "Total Bonus"
FROM jobdepartment AS j
INNER JOIN salarybonus AS s
ON s.Job_ID = j.Job_ID
GROUP BY j.jobdept
ORDER BY SUM(s.bonus) DESC
LIMIT 1;

# What is the average value of total_amount after considering leave deductions?
SELECT ROUND(AVG(total_amount), 2) AS "Average Value of Total Amount After Leave Deductions"
FROM Payroll;